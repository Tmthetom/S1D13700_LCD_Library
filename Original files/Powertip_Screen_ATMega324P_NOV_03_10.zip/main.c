#include <avr/io.h>
#include "sed1335.h"
#include "graphic.h"
#include "logos.h"
#include <util/delay.h>

void pixel_test(void);
void logo_test(void);
void line_test(void);
void circle_test(void);


int main(void)
{
	/* Start stability test */
	_delay_ms(300);
	
	GLCD_Initialize();



	while(1)
	{
		logo_test();
		_delay_ms(3000);
		pixel_test();
		_delay_ms(3000);
		line_test();
		_delay_ms(3000);
		circle_test();
		_delay_ms(3000);
	}

	while(1);
}
void logo_test(void)
{
	char buf[] = "Stability Test";
	GLCD_ClearText();
	GLCD_ClearGraphic();
	GLCD_TextGoTo(0,0);
	GLCD_WriteText(buf);
	GLCD_TextGoTo(26,29);
	GLCD_WriteText(buf);
	GLCD_Bitmap((char *) logos, 0, 0, 320, 240);
}
void pixel_test(void)
{
	int x;
	int y;
	unsigned char c;

	GLCD_ClearText();
	GLCD_ClearGraphic();

	c = 0;
	for (y = 0; y < 240; y++)
	{
		c = !c;
		for (x = 0; x < 320; x++)
		{
			c = !c;
			GLCD_SetPixel(x,y,c);
		}
	}
}
void line_test(void)
{

	int x1;
	int y1;
	int x2;
	int y2;
	int i;

	GLCD_ClearText();
	GLCD_ClearGraphic();

	x1 = 0; y1 = 0; x2 = 319; y2 = 239;

	for (i = 0; i < 160; i++)
	{
		GLCD_Line(x1, y1,x2,y2);
		x1+=2;
		x2-=2;
	}

	x1 = 0; y1 = 0; x2 = 319; y2 = 239;

	for (i = 0; i < 120; i++)
	{
		GLCD_Line(x1, y1,x2,y2);
		y1+=2;
		y2-=2;
	}

}
void circle_test(void)
{
	int x1;
	int y1;
	int r;
	int i;

	x1 = 160; y1 = 120; r = 10;

	GLCD_ClearText();
	GLCD_ClearGraphic();

	for (i = 0; i < 55; i++)
	{
		GLCD_Circle(x1,y1,r);
		r += 2;
	}
}


